use agora::utils::{TreeNode, TreeTrait};
use std::rc::Rc;

fn create_test_sample() -> Rc<TreeNode> {
    let root = TreeNode::new("project");
    root.add_children(&["src", "target", "tests", "docs"]);
    let src = root.get_child("src").unwrap();
    src.add_children(&["main.rs", "utils.rs"]);
    let target = root.get_child("target").unwrap();
    target.add_children(&["debug", "release"]);
    let tests = root.get_child("tests").unwrap();
    tests.add_children(&["test1.rs", "test2.rs"]);
    return root;
}

fn create_test_sample_with_branch() -> Rc<TreeNode> {
    let root = TreeNode::new("project");
    root.add_children(&["src", "test"]);
    let src = root.get_child("src").unwrap();
    let test = root.get_child("test").unwrap();
    src.add_children(&["main.rs"]);
    test.add_children(&["test_folder", "test_file"]);
    let folder1 = test.get_child("test_folder").unwrap();
    folder1.add_children(&["test.rs"]);
    return root;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn print_children_test() {
        let root = TreeNode::new("project");
        root.add_children(&["src", "docs", "tests"]);
        let tree_output = root.to_string();

        let expected = "└── project\n    ├── src\n    ├── docs\n    └── tests";
        assert_eq!(
            tree_output, expected,
            "Tree structure should match expected format"
        );
    }

    #[test]
    fn children_test() {
        // Tests that:
        // - Root has 4 children, as specified
        // - Immediate and recursive children can be accessed by path
        let root = create_test_sample();
        assert_eq!(root.children().len(), 4, "Root should have 4 children");

        // Check that children can be accessed
        assert_eq!(
            root.get_child("src").unwrap().name(),
            "src",
            "src should be a child of root"
        );
        assert_eq!(
            root.get_child("docs").unwrap().name(),
            "docs",
            "docs should be a child of root"
        );
        assert_eq!(
            root.get_child("tests").unwrap().name(),
            "tests",
            "tests should be a child of root"
        );
        assert_eq!(
            root.get_child("target").unwrap().name(),
            "target",
            "target should be a child of root"
        );
        // Nonexistent child should return None
        match root.get_child("does_not_exist") {
            Err(_) => (),
            Ok(_) => panic!("should not be a child of root"),
        }

        assert_eq!(
            root.get_child("src/main.rs").unwrap().name(),
            "main.rs",
            "main.rs should be a child of src"
        )
    }

    #[test]
    fn path_test() {
        let root = create_test_sample();
        assert_eq!(
            root.get_child("src/main.rs").unwrap().path(),
            "/project/src/main.rs",
        );
        assert_eq!(root.path(), "/project", "path should be project");
        assert_eq!(root.get_child("src").unwrap().path(), "/project/src")
    }

    #[test]
    fn remove_child_test() {
        let root = create_test_sample();
        root.remove_child("src").unwrap();
        // Checks that removal is accurate
        assert_eq!(root.children().len(), 3, "Root should have 3 children");
        assert!(root.get_child("src").is_err(), "src should be removed");
        assert!(
            root.get_child("src/main.rs").is_err(),
            "src/main.rs should be removed"
        );
        // Cannot remove nonexistent child
        match root.remove_child("does_not_exist") {
            Err(_) => (),
            Ok(_) => panic!("should not be able to remove does_not_exist"),
        }
        // Remove non-immediate child
        let _ = root.get_child("tests/test2.rs").unwrap();
        root.remove_child("tests/test2.rs").unwrap();
        assert_eq!(
            root.get_child("tests").unwrap().children().len(),
            1,
            "tests should have 1 child"
        );
        assert!(
            root.get_child("tests/test2.rs").is_err(),
            "test2.rs should be removed"
        );
        assert_eq!(
            root.to_string(),
            "└── project\n    ├── target\n    │   ├── debug\n    │   └── release\n    ├── tests\n    │   └── test1.rs\n    └── docs"
        )
    }

    #[test]
    fn root_parent_test() {
        let root = create_test_sample();
        let child = root.get_child("target/debug").unwrap();
        assert_eq!(root.to_string(), child.root().to_string());

        child.root().remove_child("target/release").unwrap();
        assert_eq!(root.to_string(), child.root().to_string());
    }

    #[test]
    fn is_root_leaf_test() {
        let root = create_test_sample();
        assert!(!root.is_leaf(), "Root should not be a leaf");
        assert!(root.is_root(), "Root should be a root");
        let leaf = root.get_child("tests/test1.rs").unwrap();
        assert!(leaf.is_leaf(), "Leaf should be a leaf");
        assert!(!leaf.is_root(), "Leaf should not be a root");
    }

    #[test]
    fn print_test() {
        let root = create_test_sample();
        let tree_output = root.to_string();
        let expected = "└── project\n    ├── src\n    │   ├── main.rs\n    │   └── utils.rs\n    ├── target\n    │   ├── debug\n    │   └── release\n    ├── tests\n    │   ├── test1.rs\n    │   └── test2.rs\n    └── docs";
        assert_eq!(
            tree_output, expected,
            "Tree structure should match expected format"
        );
    }

    #[test]
    fn branching_ancestor_test() {
        let root = create_test_sample_with_branch();
        assert_eq!(
            root.to_string(),
            "└── project\n    ├── src\n    │   └── main.rs\n    └── test\n        ├── test_folder\n        │   └── test.rs\n        └── test_file",
            "Tree structure should match expected format"
        );
        assert_eq!(
            root.remove_child_and_branch("test/test_folder"),
            Err(format!("Cannot remove non-leaf node")),
        );
        // Removing root should fail
        match root.remove_child_and_branch("") {
            Err(_) => (),
            Ok(_) => panic!("should not be able to remove root"),
        }
        root.remove_child_and_branch("src/main.rs").unwrap();
        assert_eq!(
            root.to_string(),
            "└── project\n    └── test\n        ├── test_folder\n        │   └── test.rs\n        └── test_file"
        );
        root.remove_child_and_branch("test/test_file").unwrap();
        assert_eq!(
            root.to_string(),
            "└── project\n    └── test\n        └── test_folder\n            └── test.rs"
        );
        root.remove_child_and_branch("test/test_folder/test.rs")
            .unwrap();
        assert_eq!(root.to_string(), "└── project");
    }

    #[test]
    fn parent_test() {
        let root = create_test_sample();
        let src = root.get_child("src").unwrap();
        assert!(root.parent().is_err(), "Root should have no parent");
        assert_eq!(
            src.parent().unwrap().name(),
            "project",
            "src should have project as parent"
        );
        assert_eq!(
            src.get_child("main.rs").unwrap().parent().unwrap().name(),
            "src",
            "main.rs should have src as parent"
        );
    }

    #[test]
    fn repr_conversion() {
        use agora::utils::TreeTrait;

        // Test 1: create_test_sample can be converted to & from repr
        let original = create_test_sample();
        let repr = original.to_repr();

        println!("\nOriginal tree representation: {}", repr);

        // Convert back from representation
        let reconstructed =
            TreeNode::from_repr(&repr).expect("Should be able to reconstruct from repr");

        // Verify the reconstructed tree has the same structure
        assert_eq!(
            original.name(),
            reconstructed.name(),
            "Root names should match"
        );
        assert_eq!(
            original.children().len(),
            reconstructed.children().len(),
            "Root should have same number of children"
        );

        // Check some specific paths exist in both
        assert!(
            original.get_child("src").is_ok(),
            "Original should have src"
        );
        assert!(
            reconstructed.get_child("src").is_ok(),
            "Reconstructed should have src"
        );
        assert!(
            original.get_child("src/main.rs").is_ok(),
            "Original should have src/main.rs"
        );
        assert!(
            reconstructed.get_child("src/main.rs").is_ok(),
            "Reconstructed should have src/main.rs"
        );
        assert!(
            original.get_child("target/debug").is_ok(),
            "Original should have target/debug"
        );
        assert!(
            reconstructed.get_child("target/debug").is_ok(),
            "Reconstructed should have target/debug"
        );

        // Test 2: after tampering with the string, things fail

        // Test case 1: Invalid quote structure
        let tampered_repr1 = repr.replace("\"project\"", "project");
        assert!(
            TreeNode::from_repr(&tampered_repr1).is_err(),
            "Should fail with missing quotes"
        );

        // Test case 2: Malformed brackets
        let tampered_repr2 = repr.replace("[", "(");
        assert!(
            TreeNode::from_repr(&tampered_repr2).is_err(),
            "Should fail with wrong brackets"
        );

        // Test case 3: Missing colon
        let tampered_repr3 = repr.replace(":", "");
        assert!(
            TreeNode::from_repr(&tampered_repr3).is_err(),
            "Should fail with missing colon"
        );

        // Test case 4: Completely invalid string
        let invalid_repr = "this is not a valid tree representation";
        assert!(
            TreeNode::from_repr(&invalid_repr).is_err(),
            "Should fail with completely invalid string"
        );

        println!("All repr conversion tests passed!");
    }
}
