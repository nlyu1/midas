1. `cargo run --bin metaserver [-p PORT]`
2. `cargo run --bin metaclient`